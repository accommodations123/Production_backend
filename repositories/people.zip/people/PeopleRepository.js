import ProfessionalProfile, { populateProfileGSIs } from "../../model/people/ProfessionalProfile.js";
import ProfessionalExperience from "../../model/people/ProfessionalExperience.js";
import ProfessionalEducation from "../../model/people/ProfessionalEducation.js";
import ProfessionalCertification from "../../model/people/ProfessionalCertification.js";
import ProfessionalCourse from "../../model/people/ProfessionalCourse.js";
import ProfessionalSkill from "../../model/people/ProfessionalSkill.js";
import ProfessionalLanguage from "../../model/people/ProfessionalLanguage.js";
import ProfessionalService from "../../model/people/ProfessionalService.js";
import ProfessionalPortfolio from "../../model/people/ProfessionalPortfolio.js";
import ProfessionalPortfolioMedia from "../../model/people/ProfessionalPortfolioMedia.js";
import ProfessionalResume from "../../model/people/ProfessionalResume.js";
import PeopleReview from "../../model/people/PeopleReview.js";
import PeopleFollower from "../../model/people/PeopleFollower.js";
import ProfessionalRecommendation from "../../model/people/ProfessionalRecommendation.js";
import PeopleReport from "../../model/people/PeopleReport.js";
import ProfessionalAnalytics from "../../model/people/ProfessionalAnalytics.js";

/* =====================================================================
   People Repository — Single-Table Data Access & GSI Helpers
   ===================================================================== */

class PeopleRepository {
  // ── Profile CRUD ───────────────────────────────────────────────────
  async findProfileById(id) {
    return await ProfessionalProfile.get(id);
  }

  async findProfileByUserId(userId) {
    const results = await ProfessionalProfile.query("user_id").eq(userId).exec();
    return results && results.length > 0 ? results[0] : null;
  }

  async saveProfile(profileData) {
    const populated = populateProfileGSIs(profileData);
    return await ProfessionalProfile.create(populated);
  }

  async updateProfile(id, updateFields) {
    const existing = await ProfessionalProfile.get(id);
    if (!existing) return null;

    const merged = { ...existing, ...updateFields, id };
    const populated = populateProfileGSIs(merged);
    return await ProfessionalProfile.update({ id }, populated);
  }

  async deleteProfile(id) {
    return await ProfessionalProfile.update({ id }, { status: "deleted" });
  }

  // ── GSI Search Access Patterns ─────────────────────────────────────
  async queryByCategory(category, titlePrefix, limit = 20, startKey = null) {
    const normCategory = (category || "").toLowerCase().trim();
    let query = ProfessionalProfile.query("gsi1pk").eq(`CATEGORY#${normCategory}`);

    if (titlePrefix) {
      const normTitle = titlePrefix.toLowerCase().trim();
      query = query.where("gsi1sk").beginsWith(`TITLE#${normTitle}`);
    }

    query = query.limit(limit);
    if (startKey) query = query.startAt(startKey);

    return await query.exec();
  }

  async queryByServices(offersServices = true, category = null, limit = 20, startKey = null) {
    const sStr = offersServices ? "true" : "false";
    let query = ProfessionalProfile.query("gsi2pk").eq(`SERVICES#${sStr}`);

    if (category) {
      const normCategory = category.toLowerCase().trim();
      query = query.where("gsi2sk").beginsWith(normCategory);
    }

    query = query.limit(limit);
    if (startKey) query = query.startAt(startKey);

    return await query.exec();
  }

  async queryByGeohashPrefix(prefix, limit = 20, startKey = null) {
    let query = ProfessionalProfile.query("gsi4pk").eq(`GEO#${prefix}`).limit(limit);
    if (startKey) query = query.startAt(startKey);
    return await query.exec();
  }

  async queryByCountry(country, limit = 20, startKey = null) {
    let query = ProfessionalProfile.query("country").eq(country).limit(limit);
    if (startKey) query = query.startAt(startKey);
    return await query.exec();
  }

  // ── Experience CRUD ────────────────────────────────────────────────
  async getExperiences(professionalId) {
    return await ProfessionalExperience.query("professionalId").eq(professionalId).exec();
  }

  async getExperienceById(id) {
    return await ProfessionalExperience.get(id);
  }

  async saveExperience(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `EXPERIENCE#${data.id || data.experienceId}`;
    return await ProfessionalExperience.create(data);
  }

  async updateExperience(id, data) {
    return await ProfessionalExperience.update({ id }, data);
  }

  async deleteExperience(id) {
    return await ProfessionalExperience.delete(id);
  }

  // ── Education CRUD ─────────────────────────────────────────────────
  async getEducation(professionalId) {
    return await ProfessionalEducation.query("professionalId").eq(professionalId).exec();
  }

  async getEducationById(id) {
    return await ProfessionalEducation.get(id);
  }

  async saveEducation(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `EDUCATION#${data.id || data.educationId}`;
    return await ProfessionalEducation.create(data);
  }

  async updateEducation(id, data) {
    return await ProfessionalEducation.update({ id }, data);
  }

  async deleteEducation(id) {
    return await ProfessionalEducation.delete(id);
  }

  // ── Certification CRUD ─────────────────────────────────────────────
  async getCertifications(professionalId) {
    return await ProfessionalCertification.query("professionalId").eq(professionalId).exec();
  }

  async getCertificationById(id) {
    return await ProfessionalCertification.get(id);
  }

  async saveCertification(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `CERTIFICATION#${data.id || data.certificationId}`;
    return await ProfessionalCertification.create(data);
  }

  async updateCertification(id, data) {
    return await ProfessionalCertification.update({ id }, data);
  }

  async deleteCertification(id) {
    return await ProfessionalCertification.delete(id);
  }

  // ── Course CRUD ────────────────────────────────────────────────────
  async getCourses(professionalId) {
    return await ProfessionalCourse.query("professionalId").eq(professionalId).exec();
  }

  async getCourseById(id) {
    return await ProfessionalCourse.get(id);
  }

  async saveCourse(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `COURSE#${data.id || data.courseId}`;
    return await ProfessionalCourse.create(data);
  }

  async updateCourse(id, data) {
    return await ProfessionalCourse.update({ id }, data);
  }

  async deleteCourse(id) {
    return await ProfessionalCourse.delete(id);
  }

  // ── Skill Replace / List ──────────────────────────────────────────
  async getSkills(professionalId) {
    return await ProfessionalSkill.query("professionalId").eq(professionalId).exec();
  }

  async replaceSkills(professionalId, ownerUserId, skillsList) {
    const existing = await this.getSkills(professionalId);
    for (const item of existing || []) {
      await ProfessionalSkill.delete(item.id);
    }
    const created = [];
    for (const name of skillsList) {
      const item = await ProfessionalSkill.create({
        professionalId,
        ownerUserId,
        name,
        normalizedName: name.toLowerCase().trim(),
        pk: `PROFESSIONAL#${professionalId}`,
        sk: `SKILL#${name.toLowerCase().trim()}`
      });
      created.push(item);
    }
    return created;
  }

  // ── Language Replace / List ───────────────────────────────────────
  async getLanguages(professionalId) {
    return await ProfessionalLanguage.query("professionalId").eq(professionalId).exec();
  }

  async replaceLanguages(professionalId, ownerUserId, languagesList) {
    const existing = await this.getLanguages(professionalId);
    for (const item of existing || []) {
      await ProfessionalLanguage.delete(item.id);
    }
    const created = [];
    for (const langObj of languagesList) {
      const langName = typeof langObj === "string" ? langObj : langObj.language;
      const proficiency = typeof langObj === "object" ? langObj.proficiency : "professional";
      const item = await ProfessionalLanguage.create({
        professionalId,
        ownerUserId,
        language: langName,
        proficiency,
        pk: `PROFESSIONAL#${professionalId}`,
        sk: `LANGUAGE#${langName.toLowerCase().trim()}`
      });
      created.push(item);
    }
    return created;
  }

  // ── Service CRUD & Status ──────────────────────────────────────────
  async getServices(professionalId) {
    return await ProfessionalService.query("professionalId").eq(professionalId).exec();
  }

  async getServiceById(id) {
    return await ProfessionalService.get(id);
  }

  async saveService(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `SERVICE#${data.id || data.serviceId}`;
    return await ProfessionalService.create(data);
  }

  async updateService(id, data) {
    return await ProfessionalService.update({ id }, data);
  }

  async deleteService(id) {
    return await ProfessionalService.delete(id);
  }

  // ── Portfolio & Media CRUD ────────────────────────────────────────
  async getPortfolio(professionalId) {
    return await ProfessionalPortfolio.query("professionalId").eq(professionalId).exec();
  }

  async getPortfolioById(id) {
    return await ProfessionalPortfolio.get(id);
  }

  async savePortfolio(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `PORTFOLIO#${data.id || data.portfolioId}`;
    return await ProfessionalPortfolio.create(data);
  }

  async updatePortfolio(id, data) {
    return await ProfessionalPortfolio.update({ id }, data);
  }

  async deletePortfolio(id) {
    return await ProfessionalPortfolio.delete(id);
  }

  async savePortfolioMedia(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `PORTFOLIO_MEDIA#${data.id || data.mediaId}`;
    return await ProfessionalPortfolioMedia.create(data);
  }

  async deletePortfolioMedia(id) {
    return await ProfessionalPortfolioMedia.delete(id);
  }

  // ── Resume CRUD ───────────────────────────────────────────────────
  async getResumes(professionalId) {
    return await ProfessionalResume.query("professionalId").eq(professionalId).exec();
  }

  async getResumeById(id) {
    return await ProfessionalResume.get(id);
  }

  async saveResume(data) {
    data.pk = `PROFESSIONAL#${data.professionalId}`;
    data.sk = `RESUME#${data.id || data.resumeId}`;
    return await ProfessionalResume.create(data);
  }

  async updateResume(id, data) {
    return await ProfessionalResume.update({ id }, data);
  }

  async deleteResume(id) {
    return await ProfessionalResume.delete(id);
  }

  // ── Follower & GSI5 Inverse Follower ──────────────────────────────
  async getFollowers(expertId) {
    return await PeopleFollower.query("expert_id").eq(expertId).exec();
  }

  async getFollower(expertId, userId) {
    const list = await PeopleFollower.query("expert_id").eq(expertId).where("user_id").eq(userId).exec();
    return list && list.length > 0 ? list[0] : null;
  }

  async saveFollower(expertId, userId) {
    const pk = `PROFESSIONAL#${expertId}`;
    const sk = `FOLLOWER#${userId}`;
    const gsi5pk = `FOLLOWING#${userId}`;
    const gsi5sk = `PROFESSIONAL#${expertId}`;
    return await PeopleFollower.create({ expert_id: expertId, user_id: userId, pk, sk, gsi5pk, gsi5sk });
  }

  async removeFollower(id) {
    return await PeopleFollower.delete(id);
  }

  async getFollowingByUserId(userId) {
    return await PeopleFollower.query("gsi5pk").eq(`FOLLOWING#${userId}`).exec();
  }

  // ── Reviews ───────────────────────────────────────────────────────
  async getReviews(expertId) {
    return await PeopleReview.query("expert_id").eq(expertId).exec();
  }

  async getReviewById(id) {
    return await PeopleReview.get(id);
  }

  async getAllReviews() {
    return await PeopleReview.scan().exec();
  }

  async saveReview(data) {
    data.pk = `PROFESSIONAL#${data.expert_id}`;
    data.sk = `REVIEW#${data.id || data.reviewId}`;
    return await PeopleReview.create(data);
  }

  async updateReview(id, data) {
    return await PeopleReview.update({ id }, data);
  }

  // ── Recommendations ───────────────────────────────────────────────
  async getRecommendations(expertId) {
    return await ProfessionalRecommendation.query("expert_id").eq(expertId).exec();
  }

  async getRecommendationById(id) {
    return await ProfessionalRecommendation.get(id);
  }

  async saveRecommendation(data) {
    data.pk = `PROFESSIONAL#${data.expert_id}`;
    data.sk = `RECOMMENDATION#${data.id || data.recommendationId}`;
    return await ProfessionalRecommendation.create(data);
  }

  async updateRecommendation(id, data) {
    return await ProfessionalRecommendation.update({ id }, data);
  }

  async deleteRecommendation(id) {
    return await ProfessionalRecommendation.delete(id);
  }

  // ── Reports ───────────────────────────────────────────────────────
  async saveReport(data) {
    data.pk = `PROFESSIONAL#${data.expert_id}`;
    data.sk = `REPORT#${data.id || data.reportId}`;
    return await PeopleReport.create(data);
  }

  async getReports() {
    return await PeopleReport.scan().exec();
  }

  async updateReport(id, data) {
    return await PeopleReport.update({ id }, data);
  }

  // ── Analytics ─────────────────────────────────────────────────────
  async saveAnalyticsEvent(data) {
    data.pk = `PROFESSIONAL#${data.expert_id}`;
    data.sk = `ANALYTICS#${data.id || data.eventId}`;
    return await ProfessionalAnalytics.create(data);
  }
}

export default new PeopleRepository();
