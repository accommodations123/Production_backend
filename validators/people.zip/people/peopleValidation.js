import Joi from "joi";

/* =====================================================================
   People Directory Input Validators (Joi Schemas)
   ===================================================================== */

export const createProfileSchema = Joi.object({
  firstName: Joi.string().max(100),
  lastName: Joi.string().max(100),
  displayName: Joi.string().max(150),
  name: Joi.string().max(150),
  headline: Joi.string().max(250),
  profession: Joi.string().max(150),
  category: Joi.string().max(100),
  bio: Joi.string().max(2000),
  about: Joi.string().max(2000),
  yearsOfExperience: Joi.number().min(0).max(70),
  country: Joi.string().max(100),
  state: Joi.string().max(100),
  city: Joi.string().max(100),
  latitude: Joi.number().min(-90).max(90),
  longitude: Joi.number().min(-180).max(180),
  skills: Joi.array().items(Joi.string().max(50)).max(50),
  languages: Joi.array().max(20),
  offersServices: Joi.boolean(),
  profileVisibility: Joi.string().valid("public", "private", "connections_only")
}).unknown(true);

export const experienceSchema = Joi.object({
  jobTitle: Joi.string().required().max(150),
  companyName: Joi.string().required().max(150),
  employmentType: Joi.string().max(50),
  startDate: Joi.string().required(),
  endDate: Joi.string().allow("", null),
  isCurrent: Joi.boolean(),
  description: Joi.string().max(2000)
}).unknown(true);

export const serviceSchema = Joi.object({
  serviceName: Joi.string().required().max(150),
  category: Joi.string().required().max(100),
  description: Joi.string().max(2000),
  pricingType: Joi.string().valid("hourly", "fixed", "starting_at", "custom"),
  price: Joi.number().min(0),
  currency: Joi.string().max(10)
}).unknown(true);

export const reviewSchema = Joi.object({
  rating: Joi.number().min(1).max(5).required(),
  comment: Joi.string().required().max(1000),
  title: Joi.string().max(150),
  anonymous: Joi.boolean()
}).unknown(true);
