import peopleRepository from "../../repositories/people/PeopleRepository.js";

/* =====================================================================
   People Service — Core Business Logic & DTO Projections
   ===================================================================== */

class PeopleService {
  /**
   * Projects a raw profile record into a public profile object,
   * stripping sensitive private data (email, phone, salary, resume key, moderation details).
   */
  toPublicDTO(profile) {
    if (!profile) return null;
    const obj = typeof profile.toJSON === "function" ? profile.toJSON() : { ...profile };

    // Strip private / internal fields
    delete obj.pk;
    delete obj.sk;
    delete obj.gsi1pk;
    delete obj.gsi1sk;
    delete obj.gsi2pk;
    delete obj.gsi2sk;
    delete obj.gsi3pk;
    delete obj.gsi3sk;
    delete obj.gsi4pk;
    delete obj.gsi4sk;

    // Respect profile visibility
    if (obj.profileVisibility === "private") {
      return {
        id: obj.id,
        professionalId: obj.id,
        displayName: obj.displayName || "Private Profile",
        profileVisibility: "private"
      };
    }

    return {
      professionalId: obj.id,
      id: obj.id,
      ownerUserId: obj.user_id,
      firstName: obj.firstName || obj.name?.split(" ")[0] || "",
      lastName: obj.lastName || obj.name?.split(" ").slice(1).join(" ") || "",
      displayName: obj.displayName || obj.name,
      name: obj.name,
      profilePhoto: obj.profilePhoto || obj.avatar,
      coverPhoto: obj.coverPhoto || obj.cover_image,
      headline: obj.headline,
      professionalTitle: obj.profession,
      profession: obj.profession,
      category: obj.category,
      about: obj.about || obj.bio,
      yearsOfExperience: obj.yearsOfExperience || 0,
      country: obj.country,
      state: obj.state,
      city: obj.city,
      district: obj.district,
      postalCode: obj.postalCode,
      latitude: obj.latitude,
      longitude: obj.longitude,
      timezone: obj.timezone,
      skills: obj.skills || [],
      specializations: obj.specializations || [],
      keywords: obj.keywords || [],
      languages: obj.languages || [],
      profileVisibility: obj.profileVisibility || "public",
      searchable: obj.searchable !== false,
      offersServices: Boolean(obj.offersServices),
      availabilityStatus: obj.availabilityStatus || obj.availability || "available",
      availableFrom: obj.availableFrom,
      acceptingClients: obj.accepting_clients !== false,
      responseTime: obj.response_time,
      socialLinks: {
        website: obj.website,
        linkedin: obj.linkedin,
        github: obj.github,
        twitter: obj.twitter,
        instagram: obj.instagram,
        youtube: obj.youtube
      },
      verification: {
        identity: Boolean(obj.identity_verified),
        documents: Boolean(obj.documents_verified),
        linkedin: Boolean(obj.linkedin_verified)
      },
      profileCompletion: this.calculateProfileCompletion(obj),
      followersCount: obj.followersCount || obj.followers_count || 0,
      reviewCount: obj.reviewCount || obj.review_count || 0,
      averageRating: obj.averageRating || obj.rating || 0,
      status: obj.status || "published",
      createdAt: obj.created_at || obj.createdAt,
      updatedAt: obj.updated_at || obj.updatedAt
    };
  }

  /**
   * Calculates profile completion percentage (0 to 100)
   */
  calculateProfileCompletion(profile) {
    let score = 0;
    if (profile.name) score += 15;
    if (profile.profession || profile.headline) score += 15;
    if (profile.bio || profile.about) score += 15;
    if (profile.city && profile.country) score += 10;
    if (profile.avatar || profile.profilePhoto) score += 15;
    if (Array.isArray(profile.skills) && profile.skills.length > 0) score += 15;
    if (profile.yearsOfExperience > 0) score += 15;
    return Math.min(score, 100);
  }

  async getProfileById(id) {
    const raw = await peopleRepository.findProfileById(id);
    return this.toPublicDTO(raw);
  }

  async getProfileByUserId(userId) {
    const raw = await peopleRepository.findProfileByUserId(userId);
    return this.toPublicDTO(raw);
  }

  async createProfile(userId, body) {
    const existing = await peopleRepository.findProfileByUserId(userId);
    if (existing) {
      throw new Error("Professional profile already exists for this user.");
    }

    const payload = {
      ...body,
      user_id: userId,
      name: body.name || `${body.firstName || ''} ${body.lastName || ''}`.trim() || "Professional User",
      profession: body.profession || body.professionalTitle || "Professional",
      category: body.category || "Technology",
      bio: body.bio || body.about || "Professional profile summary.",
      country: body.country || "USA",
      city: body.city || "New York"
    };

    const created = await peopleRepository.saveProfile(payload);
    return this.toPublicDTO(created);
  }

  async updateProfile(id, userId, body) {
    const existing = await peopleRepository.findProfileById(id);
    if (!existing) {
      throw new Error("Professional profile not found.");
    }
    if (existing.user_id !== userId) {
      throw new Error("Unauthorized to update this profile.");
    }

    const updated = await peopleRepository.updateProfile(id, body);
    return this.toPublicDTO(updated);
  }
}

export default new PeopleService();
