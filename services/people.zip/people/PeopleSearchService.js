import peopleRepository from "../../repositories/people/PeopleRepository.js";
import { encodeGeohash, calculateHaversineDistance } from "../../utils/geohash.js";

/* =====================================================================
   People Search Service — Production DynamoDB Search & Filter Engine
   Uses deterministic GSIs (GSI1, GSI2, GSI4) to avoid table Scans.
   ===================================================================== */

class PeopleSearchService {
  /**
   * Decodes base64 pagination cursor into DynamoDB LastEvaluatedKey object
   */
  decodeCursor(cursorStr) {
    if (!cursorStr) return null;
    try {
      return JSON.parse(Buffer.from(cursorStr, "base64").toString("utf-8"));
    } catch {
      return null;
    }
  }

  /**
   * Encodes DynamoDB LastEvaluatedKey into base64 pagination cursor string
   */
  encodeCursor(lastEvaluatedKey) {
    if (!lastEvaluatedKey) return null;
    try {
      return Buffer.from(JSON.stringify(lastEvaluatedKey)).toString("base64");
    } catch {
      return null;
    }
  }

  /**
   * Executes deterministic GSI search query with post-filtering and cursor pagination.
   */
  async search(params = {}) {
    const {
      search,
      category,
      profession,
      country,
      city,
      distance,
      latitude,
      longitude,
      offersServices,
      verified,
      availability,
      experienceMin,
      experienceMax,
      minRating,
      cursor,
      limit = 20
    } = params;

    const startKey = this.decodeCursor(cursor);
    const numericLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 50);

    let rawItems = [];
    let nextEvaluatedKey = null;

    const reqLat = parseFloat(latitude);
    const reqLon = parseFloat(longitude);
    const maxDist = parseFloat(distance);

    // ── GSI Strategy Selection ─────────────────────────────────────────
    if (!isNaN(reqLat) && !isNaN(reqLon) && !isNaN(maxDist) && maxDist > 0) {
      // Strategy: Spatial Cell Query via GSI4 (Geohash)
      const centerHash = encodeGeohash(reqLat, reqLon, 6);
      const prefix = centerHash.slice(0, 4);
      const res = await peopleRepository.queryByGeohashPrefix(prefix, numericLimit * 2, startKey);
      rawItems = res || [];
      nextEvaluatedKey = res.lastKey || null;
    } else if (offersServices === "true" || offersServices === true) {
      // Strategy: Service Discovery via GSI2
      const res = await peopleRepository.queryByServices(true, category, numericLimit * 2, startKey);
      rawItems = res || [];
      nextEvaluatedKey = res.lastKey || null;
    } else if (category) {
      // Strategy: Category & Title Discovery via GSI1
      const titleSearch = profession || search;
      const res = await peopleRepository.queryByCategory(category, titleSearch, numericLimit * 2, startKey);
      rawItems = res || [];
      nextEvaluatedKey = res.lastKey || null;
    } else if (country) {
      // Strategy: Country Index
      const res = await peopleRepository.queryByCountry(country, numericLimit * 2, startKey);
      rawItems = res || [];
      nextEvaluatedKey = res.lastKey || null;
    } else {
      // Strategy: Default Category fallback (Technology/Default) to prevent unbounded Scan
      const res = await peopleRepository.queryByCategory("technology", null, numericLimit * 2, startKey);
      rawItems = res || [];
      nextEvaluatedKey = res.lastKey || null;
    }

    // ── In-Memory Filters & Distance Post-filtering ───────────────────
    let items = rawItems.filter((item) => {
      // Must be active / published
      if (item.status === "deleted" || item.status === "suspended") return false;
      if (item.searchable === false) return false;

      // Distance check using Haversine formula
      if (!isNaN(reqLat) && !isNaN(reqLon) && !isNaN(maxDist) && maxDist > 0) {
        if (typeof item.latitude !== "number" || typeof item.longitude !== "number") {
          return false;
        }
        const dist = calculateHaversineDistance(reqLat, reqLon, item.latitude, item.longitude);
        item._distanceKm = Math.round(dist * 10) / 10;
        if (dist > maxDist) return false;
      }

      // Keyword / Title / Profession text match
      if (search) {
        const q = search.toLowerCase().trim();
        const fullText = `${item.name || ''} ${item.displayName || ''} ${item.profession || ''} ${item.headline || ''} ${item.bio || ''} ${(item.skills || []).join(' ')}`.toLowerCase();
        if (!fullText.includes(q)) return false;
      }

      // City filter
      if (city && item.city) {
        if (item.city.toLowerCase() !== city.toLowerCase()) return false;
      }

      // Verification check
      if (verified === "true" || verified === true) {
        if (!item.identity_verified && !item.documents_verified) return false;
      }

      // Availability check
      if (availability && item.availabilityStatus) {
        if (item.availabilityStatus.toLowerCase() !== availability.toLowerCase()) return false;
      }

      // Experience min/max
      const yoe = item.yearsOfExperience || 0;
      if (experienceMin && yoe < parseInt(experienceMin, 10)) return false;
      if (experienceMax && yoe > parseInt(experienceMax, 10)) return false;

      // Rating min
      const rating = item.averageRating || item.rating || 0;
      if (minRating && rating < parseFloat(minRating)) return false;

      return true;
    });

    // Truncate to limit
    const hasMore = items.length > numericLimit || Boolean(nextEvaluatedKey);
    const finalItems = items.slice(0, numericLimit);

    return {
      items: finalItems,
      nextCursor: hasMore ? this.encodeCursor(nextEvaluatedKey || { id: finalItems[finalItems.length - 1]?.id }) : null,
      hasMore
    };
  }
}

export default new PeopleSearchService();
